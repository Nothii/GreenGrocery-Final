package Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;



import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Customer;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Login;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.cart;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.product2;


public interface Cart_repo extends JpaRepository<cart, Integer> {
	Optional<cart> findByCustomerAndProduct(Login customer, product2 product);
}