package Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Customer;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Login;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.cart;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.cart2;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.product2;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.cart3;

public interface Cart_repo3 extends JpaRepository<cart3, Integer> {
	Optional<cart3> findByProduct_Id(Integer productId);
}