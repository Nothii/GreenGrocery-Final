package Greengrocery_1.src.main.java.com.example.Greengrocery_1.service;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.CheckoutRequest;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Login;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Payment2;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.cart3;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.product4;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.Cart_repo3;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.Payment_Repo;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.Product_repo4;

import java.util.List;



@Service
public class CartService2 {

    @Autowired
    private Cart_repo3 cartRepository;

    @Autowired
    private Product_repo4 productRepository;

    @Autowired
    private Payment_Repo paymentRepository;

    public List<cart3> getAllCartItems() {
        return cartRepository.findAll();
    }

    public void removeItemFromCart(Integer productId) {
        cart3 cartItem = cartRepository.findByProduct_Id(productId)
                .orElseThrow(() -> new RuntimeException("Cart item not found"));
        cartRepository.delete(cartItem);
    }

    public cart3 updateQuantity(Integer productId, int newQuantity) {
        cart3 cartItem = cartRepository.findByProduct_Id(productId)
                .orElseThrow(() -> new RuntimeException("Cart item not found"));

        product4 product = productRepository.findById(cartItem.getProduct().getId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        int availableStock = product.getStockQuantity();
        int maxQuantity = Math.min(availableStock, 10);

        if (newQuantity < 1 || newQuantity > maxQuantity) {
            throw new RuntimeException("Quantity must be between 1 and " + maxQuantity);
        }

        cartItem.setQuantity(newQuantity);
        cartItem.setPrice(newQuantity * product.getDiscountedPrice()); // Update the price based on the new quantity
        return cartRepository.save(cartItem);
    }

    public Payment2 processPayment(List<cart3> cartItems) {
        double totalPrice = 0.0;

        for (cart3 cartItem : cartItems) {
            cart3 cartItemEntity = cartRepository.findByProduct_Id(cartItem.getProduct().getId())
                    .orElseThrow(() -> new RuntimeException("Cart item not found"));

            cartItemEntity.setQuantity(cartItem.getQuantity());
            cartItemEntity.setPrice(cartItem.getQuantity() * cartItemEntity.getProduct().getDiscountedPrice());
            cartRepository.save(cartItemEntity);
            
            totalPrice += cartItemEntity.getPrice();
        }

        // Apply discount if total price exceeds $100
        if (totalPrice > 100) {
            totalPrice -= 5; // Apply $5 discount
        }

        Payment2 payment = new Payment2();
        payment.setTotalPrice(totalPrice);

        // Don't delete cart items here, just save the payment info
        return paymentRepository.save(payment);
    }
}
