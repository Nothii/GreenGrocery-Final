package Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Customer;


public interface CustomerRepository extends JpaRepository<Customer, Integer> {

}
