package Greengrocery_1.src.main.java.com.example.Greengrocery_1.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

import jakarta.persistence.*;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "Reviews")
public class Review {
    
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ReviewId")
    private int reviewId;

    @ManyToOne
    @JoinColumn(name = "CustomerID", nullable = false)
    @JsonBackReference
    private Customer2 customer;

    @Column(name = "Rating", length = 50)
    private String rating;

    @Column(name = "Comments", length = 100)
    private String comments;

    @Column(name = "DateOfPost")
    private LocalDateTime dateOfPost;

    // Getters and Setters
    
    public int getReviewId() {
		return reviewId;
	}

	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}

	public Customer2 getCustomer() {
		return customer;
	}

	public void setCustomer(Customer2 customer) {
		this.customer = customer;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public LocalDateTime getDateOfPost() {
		return dateOfPost;
	}

	public void setDateOfPost(LocalDateTime dateOfPost) {
		this.dateOfPost = dateOfPost;
	}

    @Override
    public String toString() {
        return "Review{" +
                "reviewId=" + reviewId +
                ", rating='" + rating + '\'' +
                ", comments='" + comments + '\'' +
                ", dateOfPost=" + dateOfPost +
                '}';
    }
}
	
	

