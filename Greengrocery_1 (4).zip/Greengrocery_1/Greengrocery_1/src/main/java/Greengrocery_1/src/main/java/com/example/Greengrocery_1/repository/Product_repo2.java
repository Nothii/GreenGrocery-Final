package Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.product3;


public interface Product_repo2 extends JpaRepository<product3, Integer> {
	
}