package Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Customer;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Customer2;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Product;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Review;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Integer> {
    List<Review> findByCustomer(Customer2 customer);
}
