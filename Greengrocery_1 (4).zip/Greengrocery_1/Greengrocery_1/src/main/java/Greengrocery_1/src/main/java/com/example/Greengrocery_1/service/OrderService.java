package Greengrocery_1.src.main.java.com.example.Greengrocery_1.service;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Order;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Payment1;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.cart2;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.product3;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.Cart_repo2;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.Order_repo;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.Payment_Repo2;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.Product_repo2;

import java.time.LocalDate;
import java.util.List;

@Service
public class OrderService {
	@Autowired
    private Cart_repo2 cartRepository;

    @Autowired
    private Order_repo orderRepository;

    @Autowired
    private Product_repo2 productRepository;
    
    @Autowired
    private Payment_Repo2 paymentRepository;

    @Transactional
    public Order createOrderFromCart(Integer cartId,Payment1 paymentdetails) {
        Optional<cart2> cartOptional = cartRepository.findById(cartId);
        if (!cartOptional.isPresent()) {
            throw new RuntimeException("Cart not found for ID: " + cartId);
        }

        cart2 cartItem = cartOptional.get();

        double totalAmount = cartItem.getPrice() * cartItem.getQuantity();

        Order order = new Order();
        order.setOrderDate(LocalDate.now());
        order.setTotalAmount(totalAmount);
        order.setOrderStatus("preparing");

        // Save the order
        order.setProductId(cartItem.getProductId());
        // Save the order
        order = orderRepository.saveAndFlush(order);

        Payment1 payment = new Payment1();
        payment.setOrderId(order.getOrderId());
        payment.setFullname(paymentdetails.getFullname());
        payment.setAddress(paymentdetails.getAddress());
        payment.setCity(paymentdetails.getCity());
        payment.setState(paymentdetails.getState());
        payment.setNameOnCard(paymentdetails.getNameOnCard());
        payment.setCreditCardNum(paymentdetails.getCreditCardNum());
        payment.setExpMonth(paymentdetails.getExpMonth());
        payment.setExpYear(paymentdetails.getExpYear());
        payment.setCvv(paymentdetails.getCvv());
        paymentRepository.save(payment);

        // Update product stock quantities
        Optional<product3> productOptional = productRepository.findById(cartItem.getProductId());
        if (productOptional.isPresent()) {
            product3 product = productOptional.get();
            product.setStockQuantity(product.getStockQuantity() - cartItem.getQuantity());
            productRepository.save(product);
        } else {
            throw new RuntimeException("Product not found for ID: " + cartItem.getProductId());
        }

        // Clear the cart
        cartRepository.delete(cartItem);

        return order;
    }
}

