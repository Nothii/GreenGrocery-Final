package Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository;

import org.springframework.data.jpa.repository.JpaRepository;



import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Customer;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Product;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.product2;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface Product_repo extends JpaRepository<product2, Integer> {
	
}
