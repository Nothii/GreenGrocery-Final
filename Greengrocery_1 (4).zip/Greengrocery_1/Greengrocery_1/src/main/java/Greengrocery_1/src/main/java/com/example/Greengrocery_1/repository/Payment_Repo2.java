package Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository;

import org.springframework.data.jpa.repository.JpaRepository;



import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Payment;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Payment1;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Payment2;


public interface Payment_Repo2 extends JpaRepository<Payment1, Integer> {
	
}