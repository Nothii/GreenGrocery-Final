package Greengrocery_1.src.main.java.com.example.Greengrocery_1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Customer2;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Review;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.CustomerRepositorylogin;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.ReviewRepository;

import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ReviewService {
    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private CustomerRepositorylogin customerRepository;

    public Review saveReview(String username, String rating, String comments) {
        Optional<Customer2> customerOptional = customerRepository.findByUsername(username);
        if (!customerOptional.isPresent()) {
            throw new RuntimeException("Customer not found");
        }
        Customer2 customer = customerOptional.get();
        Review review = new Review();
        review.setCustomer(customer);
        review.setRating(rating);
        review.setComments(comments);
        review.setDateOfPost(LocalDateTime.now());
        return reviewRepository.save(review);
    }

    public List<Review> getAllReviews() {
        return reviewRepository.findAll();
    }
}
