package Greengrocery_1.src.main.java.com.example.Greengrocery_1.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "Products")
public class product4 {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY )
	@Column(name="ProductId")
    private Integer id;
	
	@Column(name= "ProductName")
    private String productName;
	
	@Column(name= "Description")
    private String description;
	
	@Column(name= "Image")
    private String image;
	
	@Column(name= "DiscountedPrice")
    private Double discountedPrice;
	
	@Column(name = "StockQuantity")
	private Integer stockQuantity;

    public Integer getStockQuantity() {
		return stockQuantity;
	}
	public void setStockQuantity(Integer stockQuantity) {
		this.stockQuantity = stockQuantity;
	}
	// Getters and Setters
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public Double getDiscountedPrice() {
		return discountedPrice;
	}
	public void setDiscountedPrice(Double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}
}
