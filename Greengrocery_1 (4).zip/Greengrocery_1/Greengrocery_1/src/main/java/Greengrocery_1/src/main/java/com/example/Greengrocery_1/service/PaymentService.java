package Greengrocery_1.src.main.java.com.example.Greengrocery_1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Payment;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.PaymentRepository;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    public Payment savePayment(Payment payment) {
        return paymentRepository.save(payment);
    }
}
