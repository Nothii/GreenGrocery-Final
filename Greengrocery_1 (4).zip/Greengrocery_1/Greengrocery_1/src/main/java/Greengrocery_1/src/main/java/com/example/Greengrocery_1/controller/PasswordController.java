package Greengrocery_1.src.main.java.com.example.Greengrocery_1.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.service.PasswordService;

import java.util.Map;

@RestController
@RequestMapping("/api/password")
public class PasswordController {

    @Autowired
    private PasswordService passwordService;

    @PostMapping("/forgot")
    public ResponseEntity<String> forgotPassword(@RequestBody Map<String, String> emailRequest) {
        String email = emailRequest.get("email");
        passwordService.sendPasswordResetEmail(email);
        return ResponseEntity.ok("If the email exists in our database, the password has been sent.");
    }
}
