package Greengrocery_1.src.main.java.com.example.Greengrocery_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Greengrocery1Application {
	public static void main(String[] args) {
		SpringApplication.run(Greengrocery1Application.class, args);
	}
}