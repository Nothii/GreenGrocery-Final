package Greengrocery_1.src.main.java.com.example.Greengrocery_1.service;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Login;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.cart;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.product2;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.Cart_repo;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.Login_repo;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.Product_repo;


@Service
public class CartService {

    @Autowired
    private Cart_repo cartRepository;

    @Autowired
    private Product_repo productRepository;

    @Autowired
    private Login_repo loginRepository;

    @Transactional
    public void addItemToCart(Integer productId) {
        // Fetch the first login entry (customer), if available
        Optional<Login> loginOptional = loginRepository.findFirstByOrderByIdAsc();
        Login customer = loginOptional.orElse(null);

        // Find the product by ID, throw an exception if not found
        product2 product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        // Check if the cart item already exists for the customer and product
        Optional<cart> cartItemOptional;
        if (customer == null) {
            cartItemOptional = cartRepository.findByCustomerAndProduct(null, product);
        } else {
            cartItemOptional = cartRepository.findByCustomerAndProduct(customer, product);
        }

        // if cart item doesn't exist, create a new one; otherwise, update the existing item
        cart cartItem;
        if (cartItemOptional.isEmpty()) {
            cartItem = new cart();
            cartItem.setCustomer(customer);
            cartItem.setProduct(product);
            cartItem.setQuantity(1);
            cartItem.setPrice(product.getDiscountedPrice());
        } else {
            cartItem = cartItemOptional.get();
            int newQuantity = cartItem.getQuantity() + 1;
            cartItem.setQuantity(newQuantity);
            cartItem.setPrice(newQuantity * product.getDiscountedPrice());
        }

        // Save the cart item to the repository
        cartRepository.save(cartItem);
    }
}
