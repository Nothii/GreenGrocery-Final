package Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.home_page;

@Repository
public interface home_repository extends JpaRepository<home_page, Integer> {
}
