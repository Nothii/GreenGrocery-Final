package Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.product4;

public interface Product_repo4 extends JpaRepository<product4, Integer> {
	
}