package Greengrocery_1.src.main.java.com.example.Greengrocery_1.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.CheckoutRequest;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Login;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Payment2;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.cart3;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.service.CartService2;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@RestController
@RequestMapping("/cart")
public class CartController2 {

    @Autowired
    private CartService2 cartService;

    @GetMapping
    public List<cart3> viewCart() {
        return cartService.getAllCartItems();
    }

    @DeleteMapping("/remove")
    public void removeItemFromCart(@RequestParam("productId") Integer productId) {
        cartService.removeItemFromCart(productId);
    }

    @PutMapping("/updateQuantity")
    public cart3 updateQuantity(@RequestBody Map<String, Object> payload) {
        Integer productId = (Integer) payload.get("productId");
        Integer newQuantity = (Integer) payload.get("newQuantity");
        return cartService.updateQuantity(productId, newQuantity);
    }

    @PostMapping("/checkout")
    public Payment2 checkout(@RequestBody List<cart3> cartItems) {
        return cartService.processPayment(cartItems);
    }
}

