package Greengrocery_1.src.main.java.com.example.Greengrocery_1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.footers;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.home_page;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.FootersRepository;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.home_repository;

import java.util.List;

@Service
public class FootersService {

    @Autowired
    private FootersRepository footersRepository;

    public List<footers> getFootersByCategory(String category) {
        return footersRepository.findByCategory(category);
    }

    public List<footers> getFruits() {
        return footersRepository.findByCategory("Fruits");
    }

    public List<footers> getVegetables() {
        return footersRepository.findByCategory("Vegetables");
    }

    public List<footers> getDrinks() {
        return footersRepository.findByCategory("Drinks");
    }
}