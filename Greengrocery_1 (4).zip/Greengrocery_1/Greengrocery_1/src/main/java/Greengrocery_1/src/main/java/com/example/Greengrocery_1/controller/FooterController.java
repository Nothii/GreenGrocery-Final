package Greengrocery_1.src.main.java.com.example.Greengrocery_1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.footers;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.home_page;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.home_repository;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.service.FootersService;

import java.util.List;

@RestController
@RequestMapping
public class FooterController {
	
	 @Autowired
	    private FootersService footersService;

	    @GetMapping("/fruits")
	    public List<footers> getFruits() {
	        return footersService.getFruits();
	    }

	    @GetMapping("/vegetables")
	    public List<footers> getVegetables() {
	        return footersService.getVegetables();
	    }

	    @GetMapping("/drinks")
	    public List<footers> getDrinks() {
	        return footersService.getDrinks();
	    }
}
