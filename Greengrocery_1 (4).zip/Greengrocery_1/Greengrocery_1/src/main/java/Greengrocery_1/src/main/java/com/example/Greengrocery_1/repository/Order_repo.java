package Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Customer1;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Order;

import java.util.Optional;

public interface Order_repo extends JpaRepository<Order, Integer> {
}