package Greengrocery_1.src.main.java.com.example.Greengrocery_1.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.service.CartService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



import java.util.Map;

@RestController
@RequestMapping
public class CartController {
    private static final Logger logger = LoggerFactory.getLogger(CartController.class);

    @Autowired
    private CartService cartService;

    @PostMapping("/add")
    public String addToCart(@RequestBody Map<String, Object> payload) {
        Integer productId = (Integer) payload.get("productId");
        logger.info("addToCart called with productId: " + productId);
        if (productId == null) {
            throw new IllegalArgumentException("Product ID must not be null");
        }
        cartService.addItemToCart(productId);
        return "Item added to cart successfully";
    }
}

