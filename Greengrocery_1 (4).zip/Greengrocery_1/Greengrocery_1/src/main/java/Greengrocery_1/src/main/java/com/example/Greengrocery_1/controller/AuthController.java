package Greengrocery_1.src.main.java.com.example.Greengrocery_1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Customer2;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.home_page;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.home_repository;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.service.CustomerService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private CustomerService customerService;

    @PostMapping("/register")
    public ResponseEntity<?> registerCustomer(@RequestBody Customer2 customer) {
        try {
            Customer2 registeredCustomer = customerService.registerCustomer(customer);
            return ResponseEntity.ok(registeredCustomer);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> loginCustomer(@RequestBody Customer2 customer) {
        Customer2 loggedInCustomer = customerService.loginCustomer(customer.getUsername(), customer.getPassword());
        if (loggedInCustomer != null) {
            return ResponseEntity.ok(loggedInCustomer);
        } else {
            return ResponseEntity.status(401).body("Invalid username or password");
        }
    }

    @GetMapping("/isLoggedIn/{username}")
    public ResponseEntity<?> isLoggedIn(@PathVariable String username) {
        boolean isLoggedIn = customerService.isCustomerLoggedIn(username);
        return ResponseEntity.ok(isLoggedIn);
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logoutCustomer(@RequestBody Map<String, String> payload) {
        String username = payload.get("username");
        customerService.logoutCustomer(username);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Logged out successfully");
        return ResponseEntity.ok(response);
    }
}
