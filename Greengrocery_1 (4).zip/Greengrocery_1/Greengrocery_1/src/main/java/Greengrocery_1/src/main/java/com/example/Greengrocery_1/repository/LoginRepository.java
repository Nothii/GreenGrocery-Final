package Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Customer;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Login;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Login2;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.cart;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.cart2;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.product2;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.cart3;

public interface LoginRepository extends JpaRepository<Login2, Long> {
    Optional<Login2> findByUsername(String username);
    Optional<Login2> findByCustomerId(Integer customerId);
}