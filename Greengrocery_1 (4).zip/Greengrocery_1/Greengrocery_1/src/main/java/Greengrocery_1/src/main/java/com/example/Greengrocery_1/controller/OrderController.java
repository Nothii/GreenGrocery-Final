package Greengrocery_1.src.main.java.com.example.Greengrocery_1.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Order;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Payment1;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.service.OrderService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@RestController
@RequestMapping("/api/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/create")
    public ResponseEntity<Order> createOrder(@RequestParam Integer cartId, @RequestBody Payment1 paymentdetails) {
        Order order = orderService.createOrderFromCart(cartId, paymentdetails);
        return ResponseEntity.ok(order);
    }
}

