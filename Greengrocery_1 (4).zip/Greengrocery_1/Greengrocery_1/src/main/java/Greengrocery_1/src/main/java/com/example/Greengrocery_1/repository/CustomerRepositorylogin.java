package Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Customer2;

import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface CustomerRepositorylogin extends JpaRepository<Customer2, Integer> {
    Optional<Customer2> findByUsername(String username);
	Optional<Customer2> findByEmail(String email);
}