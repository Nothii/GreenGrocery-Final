package com.example.Greengrocery_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Greengrocery1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
